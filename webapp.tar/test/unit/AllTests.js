sap.ui.define([
	"rrhh/rrhh/test/unit/controller/App.controller"
], function () {
	"use strict";
});
